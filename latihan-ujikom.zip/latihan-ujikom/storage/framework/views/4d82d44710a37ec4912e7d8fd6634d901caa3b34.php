

<?php $__env->startSection('title', 'Edit Data Konsumen'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<div class="row">
    <div class="col-md-12">
    
        <h2 class="page-title">Edit Data Konsumen</h2>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <!-- <div class="panel-heading">Tambah Data Konsumen</div> -->
                    <div class="panel-body">
                        <form method="POST" action="<?php echo e(route('konsumen.update', $konsumen->id)); ?>" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Kode Konsumen</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly value="<?php echo e($konsumen->kode_user); ?>" name="kode_konsumen" class="form-control">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Nama</label>
                                <div class="col-sm-10">
                                    <input type="text" value="<?php echo e($konsumen->name); ?>" name="nama" class="form-control" autofocus>
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Email</label>
                                <div class="col-sm-10">
                                    <input type="text" value="<?php echo e($konsumen->email); ?>" name="email" class="form-control">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">No Telepon</label>
                                <div class="col-sm-10">
                                <input type="number" value="<?php echo e($konsumen->no_telp); ?>" name="no_telepon"class="form-control">
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Alamat</label>
                                <div class="col-sm-10">
                                <textarea name="alamat" id="" class="form-control" rows="5"><?php echo e($konsumen->alamat); ?></textarea>
                                    
                                </div>
                                </div>
                            </div>
                        </div>
                        
                            <!-- <div class="form-group">
                                <label class="col-sm-2 control-label">Kode User</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control">
                                </div>
                                </div> -->
                                
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-2">
                                <button class="btn btn-primary" type="submit">Save</button>
                                    <button class="btn btn-default" type="submit">Cancel</button>
                                    
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>

        </div>
        


    </div>
</div>

<!-- <div class="row">
    <div class="clearfix pt pb">
        <div class="col-md-12">
            <em>Thank you for using <a href="http://themestruck.com/theme/harmony/"> Harmony Admin Theme </a> by <a href="http://themestruck.com/">ThemeStruck</a></em>
        </div>
    </div>
</div> -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RPL30\projects\latihan-ujikom\resources\views/konsumen/edit.blade.php ENDPATH**/ ?>