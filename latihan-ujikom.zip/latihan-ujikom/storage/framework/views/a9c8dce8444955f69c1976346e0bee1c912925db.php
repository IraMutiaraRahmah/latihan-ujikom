

<?php $__env->startSection('content'); ?>
<div>
Hallo ini section
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RPL30\projects\latihan-ujikom\resources\views/index.blade.php ENDPATH**/ ?>