@extends('layouts.dashboard')

@section('title', 'Tambah Data Karyawan')

@section('content')
<div class="container-fluid">

<div class="row">
    <div class="col-md-12">
    
        <h2 class="page-title">Tambah Data Karyawan</h2>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <!-- <div class="panel-heading">Tambah Data Konsumen</div> -->
                    <div class="panel-body">
                        <form method="POST" action="{{ route('karyawan.store') }}" class="form-horizontal">
                            @csrf
                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Kode Karyawan</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly value="{{$kode}}" name="kode_karyawan" class="form-control">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Nama</label>
                                <div class="col-sm-10">
                                    <input type="text" name="nama" class="form-control" autofocus>
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Email</label>
                                <div class="col-sm-10">
                                    <input type="text" name="email" class="form-control">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">No Telepon</label>
                                <div class="col-sm-10">
                                <input type="number" name="no_telepon"class="form-control">
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Alamat</label>
                                <div class="col-sm-10">
                                <textarea name="alamat" id="" class="form-control" rows="5"></textarea>
                                    
                                </div>
                                </div>
                            </div>
                        </div>
                        
                            <!-- <div class="form-group">
                                <label class="col-sm-2 control-label">Kode User</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control">
                                </div>
                                </div> -->
                                
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-2">
                                <button class="btn btn-primary" type="submit">Save</button>
                                    <button class="btn btn-default" type="submit">Cancel</button>
                                    
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>

        </div>
        


    </div>
</div>

<!-- <div class="row">
    <div class="clearfix pt pb">
        <div class="col-md-12">
            <em>Thank you for using <a href="http://themestruck.com/theme/harmony/"> Harmony Admin Theme </a> by <a href="http://themestruck.com/">ThemeStruck</a></em>
        </div>
    </div>
</div> -->

</div>
@endsection