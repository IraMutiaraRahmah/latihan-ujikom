@extends('layouts.test')

@section('content')
<div>
Hallo ini section
</div>
@endsection