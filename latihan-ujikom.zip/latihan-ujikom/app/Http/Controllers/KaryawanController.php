<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class KaryawanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $karyawan = User::role('karyawan')->get();

        return view('karyawan.index', compact('karyawan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $kode = 'KRY' . str_pad(User::orderBy('id', 'desc')->first()->id + 1, 4, '0', STR_PAD_LEFT);

        return view('karyawan.create', compact('kode'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */     
    public function store(Request $request)
    {
        $user = User::create([
            'kode_user' => $request->kode_karyawan,
            'name' => $request->nama,
            'email' => $request->email,
            'alamat' => $request->alamat, 
            'no_telp'=> $request->no_telepon,
            'password' => 'NOTASSIGN',
        ]);
        $user->assignRole('karyawan');

        return redirect()->route('karyawan.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $konsumen = User::findOrFail($id);

        return view('karyawan.edit', compact('karyawan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $karyawan = User::findOrFail($id);
        $karyawan -> update([

        'name' => $request->nama,
        'email' => $request->email,
        'no_telp'=> $request->no_telepon,
        'alamat' => $request->alamat,

        ]);
        
        return redirect()->route('karyawan.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         // 1. cari dulu user dengan id yang di kirim 
         $user = User::find($id);

         // 2. delete user yang sudah di cari
         $user->delete();
 
         // 3. balik lagi ke table
         return redirect()->route('karyawan.index');
    }
}
